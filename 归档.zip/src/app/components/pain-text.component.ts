import { Component } from '@angular/core';

@Component({
  selector: 'pl-1-plain-text',
  template: ` Folks, you're awesome! `,
})
export class PlainTextComponent {}
